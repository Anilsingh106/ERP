import styled from "styled-components";

export const MainPicker = styled.div`
width: 115px;
`