import styled from "styled-components";

export const TextContainer = styled.div`
  padding: 25px;
`;

export const Heading = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
`;
