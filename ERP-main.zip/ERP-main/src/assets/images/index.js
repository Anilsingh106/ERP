import background from './background.jpg'
import logo from './logo.jpg'
import profile from './profile.jpg'

const Images = {
    background , logo ,profile
}
export {Images};